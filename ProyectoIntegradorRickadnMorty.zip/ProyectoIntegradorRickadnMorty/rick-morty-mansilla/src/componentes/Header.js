function Titulo() {
    return(
                        <h1>
                        Rick and Morty <span>Characters</span> 
                        </h1>
				
    );
}

export default Titulo;