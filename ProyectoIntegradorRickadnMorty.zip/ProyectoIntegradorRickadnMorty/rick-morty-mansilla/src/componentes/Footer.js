function Footer() {
    return(
                        <h3>
                        Mansilla - Romero - Groszmann
                        </h3>
				
    );
}

export default Footer;